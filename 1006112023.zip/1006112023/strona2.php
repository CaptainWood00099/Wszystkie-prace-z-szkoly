<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>działania matematyczne</title>
</head>
<body>
    <header><img src="baner.jpg" alt="zdjecie" a href="index.html"></header>
<legend>POTEGOWANIE</legend>
podaj podstawę potęgi<input type="number" id="a"><br>
podaj dodatni, całkowity wykładnik potęgi<input type="number" id="b"><br>
<button id="dzielenie" onclick="POTEG()">POTĘGOWANIE</button>
<p id="odp3"></p><br>
<script src="skrypt.js"></script>
</body>
</html>
