function ADD() {
    var a = parseFloat(document.getElementById("a").value);
    var b = parseFloat(document.getElementById("b").value);
    var DOD = a + b;
    document.getElementById("odp").innerHTML = "Wynik tego działania to: " + DOD;
}
function SUB(){
    a=document.getElementById("a").value;
    b=document.getElementById("b").value;
    SUBS=a-b;
    document.getElementById("odp").innerHTML="wynik tego dzialanie to: " + SUBS ;
}
function MNOZ(){
    a=document.getElementById("a").value;
    b=document.getElementById("b").value;
    MNOZE=a*b;
    document.getElementById("odp").innerHTML="wynik tego dzialanie to: " + MNOZE ;
}
function DZIEL(){
    a=document.getElementById("a").value;
    b=document.getElementById("b").value;
    if(a!=0 && b!=0){
    DZIELENIE=a/b;
    document.getElementById("odp").innerHTML="wynik tego dzialanie to: " + DZIELENIE ;
    }
    else{
        document.getElementById("odp").innerHTML="Nie dziel przez zero!";
    }
}
function POTEG(){
   let a=document.getElementById("a").value;
   let b=document.getElementById("b").value;
    POTEGA=pow(a,b);
    document.getElementById("odp3").innerHTML="wynik tego dzialanie to: " + POTEGA ;
}