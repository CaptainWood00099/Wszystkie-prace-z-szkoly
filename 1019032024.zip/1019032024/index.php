<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style4.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Odżywanie zwierząt</title>
</head>
<body>
<div class="container">

<div class="banner">
<h2>DRAPIEŻNIKI I INNE</h2>
</div>
<div class="FORMUL">
<form action="" method="post">
<h3>Wybierz styl życia:</h3> <br>
<select name="" id="">
    <option value="meat">Drapieżniki</option>
    <option value="vege">Roślinożerne</option>
    <option value="vult">Padlinożerne</option>
    <option value="all">Wszystkożerne</option>
</select>
<input type="submit" value="Zobacz">
</form>

</div>
<div class="LEFT">
<h3>Lista zwierząt</h3>
<ul>

    <?php
			$conn= mysqli_connect('localhost', 'root', '', 'wilki');
			$que = "SELECT `zwierzeta`.`gatunek`, `odzywianie`.`rodzaj` FROM `zwierzeta` INNER JOIN `odzywianie` ON `odzywianie`.`id` = `zwierzeta`.`Odzywianie_id`";
			$query = mysqli_query($connect, $que);
			while ($linia = mysqli_fetch_assoc($query)) {
                echo "<li>" . $linia['gatunek'] . " " . $linia['rodzaj'] . "</li>";
			}
            
            
			mysqli_close($conn);
			?>
            </ul>
</div>
<div class="MAIN">
<?php
		$conn= mysqli_connect('localhost', 'root', '', 'wilki');
		$list = $_POST['list'];
		$que = "SELECT `zwierzeta`.`id`, `zwierzeta`.`gatunek`, `zwierzeta`.`wystepowanie` FROM `zwierzeta` INNER JOIN `odzywianie` ON `odzywianie`.`id` = `zwierzeta`.`Odzywianie_id` WHERE `zwierzeta`.`Odzywianie_id` = $list ";
		$query = mysqli_query($connect, $que);

		if (isset($_POST['list'])) {
			if ($list == 1) {
				echo "<h3>" . "Drapieżniki" . "</h3>";
			} else if ($list == 2) {
				echo "<h3>" . "Roślinożerne" . "</h3>";
			} else if ($list == 3) {
				echo "<h3>" . "Padlinożerne" . "</h3>";
			} else if ($list == 4) {
				echo "<h3>" . "Wszytkożerne" . "</h3>";
			}
		}

		while ($linia = mysqli_fetch_assoc($query)) {
			echo $linia['id'] . ", " . $linia['gatunek'] . ", " . $linia['wystepowanie'] . "<br>";
		}
		mysqli_close($conn);
		?>
</div>
<div class="RIGTH">
    <img src="drapieznik.jpg" alt="Wilki">

</div>

</div>    
<footer><a href="pl.wikipedia.org">Poczytaj o zwierzętach na Wikipedii</a> autor strony: 1019032024</footer>
</body>
</html>