<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Funkcje formatowania na ciągach znaków w PHP.</h2>
    <h3>Wyprowadzanie komunikatów na witrynie.</h3>
    <?php
    $txt1= "Jestem mistrzem ";
    echo str_replace("Jestem", "Oskar", $txt1);
    ?>

</body>
</html>