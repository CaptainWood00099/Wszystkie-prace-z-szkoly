<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>substring</h1> <br>
    <p>
        <?php
$x = "Hello World! <br>";
echo $x;
echo "Fragment tekstu złożony z 5 znaków zaczynając od 6 znaku: ".substr($x, 6, 5);
?> 
</p>


</body>
</html>