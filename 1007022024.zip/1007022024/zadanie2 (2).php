<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Funkcje formatowania na ciągach znaków w PHP.</h2>
    <h3>Wyprowadzanie komunikatów na witrynie.</h3>
    <p>

        <?php
    $txt1= "Jest    to tylko test, nie martw sie :) ";
    echo "Tak wygląda standardowy tekst"
    echo $txt1;
    echo strrev($txt1);
    echo trim($txt1);
    
    ?>
    </p>

</body>
</html>