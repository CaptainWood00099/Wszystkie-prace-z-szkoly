<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salon pielęgnacji</title>
    <link rel="stylesheet" href="salon.css">
</head>
<body>
    <div class="container">

        <div id="baner">
            <h1>SALON PIELĘGNACJI PSÓW I KOTÓW</h1>
    </div>
    <div id="LEFT">
        <h3>SALON ZAPRASZA W DNIACH</h3>
        <ul>
            <li>Poniedziałek, 12:00 - 18:00</li>
            <li>Wtorek, 12:00 - 18:00</li>
        </ul>
            <a href="pies.jpg"><img src="pies-mini.jpg" alt="pies-mini"></a>
            <p id="left">Umów się telefonicznie na wizytę lub po prostu przyjdź!</p>
    </div>
    <div id="CENT">
        <h3>PRZYPOMNIENIE O NASTEPNEJ WIZYCIE</h3>
        <?php
        $x=mysqli_connect('localhost', 'root', '','salon');
        $z="SELECT imie, rodzaj, nastepna_wizyta, telefon FROM zwierzeta WHERE zwierzeta.nastepna_wizyta!=0;";
        $y=mysqli_query($x,$z);
        while($a = mysqli_fetch_array($y)){
            if($a[1]==1){
                echo "Pies ".$a[0]."<br>Data następnej wizyty: ".$a[2].", telefon własiciela: ".$a[3]."<br>" ;
            }else{
                echo "Kot ".$a[0]."<br>Data następnej wizyty: ".$a[2].", telefon własiciela: ".$a[3]."<br>" ;
            }    
        }
        mysqli_close($x);
        ?>
    </div>
    <div id="RIGTH">
        <h3>USŁUGI</h3>
        <?php
        $x=mysqli_connect('localhost', 'root', '','salon');
        $z="SELECT nazwa, cena FROM uslugi;";
        $y=mysqli_query($x,$z);
        while($a = mysqli_fetch_array($y)){
            echo $a[0].", ".$a[1]."<br>";
        }
        mysqli_close($x);
        ?>
    </div>
</div>
</body>
</html>