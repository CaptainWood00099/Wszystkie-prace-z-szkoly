function licz(){
    x=document.getElementById("pass");
    y=x.length();
    z=x.search([0-9]);
    if(x.length()>6 && z==1){
        document.getElementsById("skrypt").innerHTML="DOBRE";
    }else if(x.length()>3 && x.length()<7 && z==1){
        document.getElementsById("skrypt").innerHTML="ŚREDNIE";
    }else{
        document.getElementById("skrypt").innerHTML="SŁABE";
    }
}