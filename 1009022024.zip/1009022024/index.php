<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $prawo="Jeżeli wydaje ci się, że wszystko jest w porządku – na pewno coś przeoczyłeś.";
    echo "<p>"substr($prawo,25,24)"</p";
    echo "<p>"substring($prawo,25,29)"</p";
    echo "<p>"slice($prawo,25,49)"</p";
    echo "<p>"str_replace($prawo,"wydaje","sądzisz")"</p";
    ?>
    <p id="wynik1"></p>
    <p id="wynik2"></p>
    <p id="wynik3"></p>
    <p id="wynik4"></p>
    <script src="skrypt.js"></script>
</body>
</html>