let prawo="Jeżeli wydaje ci się, że wszystko jest w porządku – na pewno coś przeoczyłeś.";
let prawo_1=prawo.substr(25,24);
let prawo_2=prawo.substring(25,49);
let prawo_3=prawo.slice(25,49);
let prawo_4=prawo.replace("wydaje", "sądzisz");
document.getElementById("wynik1").innerHTML=prawo_1;
document.getElementById("wynik2").innerHTML=prawo_2;
document.getElementById("wynik3").innerHTML=prawo_3;
document.getElementById("wynik4").innerHTML=prawo_4;

//prawo_4 w moim zadaniu to prawo_2 w tekście który dał Pan :)