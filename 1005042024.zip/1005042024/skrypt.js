function kolorBG(kolor){
    let prawy=document.getElementById("RIGTH");
    prawy.style.background=kolor;
}
function kolorFont(){
    let prawy=document.getElementById("RIGTH");
    let kolor=document.getElementById("lista");
    prawy.style.color=kolor.value;
}
function rozmiarFont(){
 let prawy=document.getElementsById("prawy");
 let rozmiar=document.getElementsById("perc").value;
 prawy.style="font-size: " +rozmiar + "%" ;  
}
function ramka(){
    let obraz=document.getElementById("obraz");
    let czyRamka= document.getElementById("border").checked;
    if(czyRamka){
        obraz.style.border="1px solid white";
    }else obraz.style.border="none";
}
function punktor(typ){
    let lista=document.getElementById("lista");
    lista.style=listStyleType=typ;
}