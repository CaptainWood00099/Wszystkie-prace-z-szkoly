-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 16, 2021 at 11:08 PM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spedycja`
--

-- --------------------------------------------------------

--
-- Table structure for table `flota`
--

CREATE TABLE `flota` (
  `id_pojazdu` int(11) NOT NULL,
  `marka` varchar(24) COLLATE utf8_polish_ci NOT NULL,
  `model` varchar(24) COLLATE utf8_polish_ci NOT NULL,
  `nr_rejestracyjny` varchar(12) COLLATE utf8_polish_ci NOT NULL,
  `id_kierowcy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `flota`
--

INSERT INTO `flota` (`id_pojazdu`, `marka`, `model`, `nr_rejestracyjny`, `id_kierowcy`) VALUES
(1, 'VOLVO', 'gt23', 'SBH 23T5', 1),
(2, 'MAN', '220x', 'KR TBZH1', 2),
(3, 'RENAULT', 'x3', 'GD 34K8', 3),
(4, 'MERCEDES', '450gb', 'KBN G28W2', 4),
(5, 'VOLVO', '12pro', 'SDG KL4S4', 5),
(6, 'MAN', '90s', 'K4 TY56', 6),
(7, 'RENAULT', '5A', 'WWA 3EDT1', 7),
(8, 'MERCEDES', '35op', 'SKA 90OR6', 8),
(9, 'RENAULT', 'as50', 'KNT 2W45I', 9),
(10, 'MAN', '2500', 'OP 190JP', 10);

-- --------------------------------------------------------

--
-- Table structure for table `kierowcy`
--

CREATE TABLE `kierowcy` (
  `id_kierowcy` int(11) NOT NULL,
  `imie` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `nazwisko` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `data_zatrudnienia` date NOT NULL,
  `prawo_jazdy` varchar(4) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `kierowcy`
--

INSERT INTO `kierowcy` (`id_kierowcy`, `imie`, `nazwisko`, `data_zatrudnienia`, `prawo_jazdy`) VALUES
(1, 'Beata', 'Konieczna', '2021-12-01', 'B'),
(2, 'Ilona', 'Konieczna', '2018-07-10', 'C+E'),
(3, 'Justyna', 'Leszczyńska', '2019-02-06', 'C+E'),
(4, 'Tamara', 'Matuszewska', '2019-02-27', 'C'),
(5, 'Marek', 'Kwiatkowski', '2020-03-14', 'C+E'),
(6, 'Wojciech', 'Krawczyk', '2016-07-20', 'C+E'),
(7, 'Bruno', 'Markiewicz', '2011-09-20', 'B'),
(8, 'Kacper', 'Urban', '2017-05-15', 'C+E'),
(9, 'Gracjan', 'Woźniak', '2016-10-16', 'C'),
(10, 'Agata', 'Kot', '2018-07-30', 'B'),
(11, 'Augustyn', 'Wojciechowski', '2014-12-19', 'C+E'),
(12, 'Przemysław', 'Michalski', '2009-02-28', 'C+E'),
(13, 'Paweł', 'Kozak', '2016-03-13', 'B'),
(14, 'Michał', 'Lewandowski', '2020-02-02', 'C'),
(15, 'Ludwika', 'Ziemba', '2021-11-07', 'C+E');

-- --------------------------------------------------------

--
-- Table structure for table `zlecenia`
--

CREATE TABLE `zlecenia` (
  `id_zlecenia` int(11) NOT NULL,
  `miasto_zaladunku` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `miasto_rozladunku` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `towar` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `spedycja` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `kwota` int(10) UNSIGNED NOT NULL,
  `numer_rejestracyjny` varchar(6) COLLATE utf8_polish_ci NOT NULL,
  `id_kierowcy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `zlecenia`
--

INSERT INTO `zlecenia` (`id_zlecenia`, `miasto_zaladunku`, `miasto_rozladunku`, `towar`, `spedycja`, `kwota`, `numer_rejestracyjny`, `id_kierowcy`) VALUES
(1, 'Kraków', 'Warszawa', 'Plastiki', 'PolSped', 120301, 'KR 13', 1),
(2, 'Gdańsk', 'Poznań', 'Słupki hektometryczne', 'Poltrans', 21020, 'KR12', 4),
(3, 'Poznań', 'Gdańsk', 'Zabawki', 'Polref', 34323, '', 1),
(4, 'Hamburg', 'Paris', 'Elektronika', 'Polsped', 31423, 'EE12', 7),
(5, 'Santa Perpetua', 'Gliwice', 'Poduszki', 'SpeedSped', 122321, '', 3),
(6, 'Madryt', 'Lyon', 'Abażury', 'ESPSped', 33133, 'ER12', 9),
(7, 'Innsbruck', 'Monachium', 'Wody mineralne', 'WodWe', 313331, 'WE133', 10),
(8, 'Londyn', 'Katowice', 'Elektronika', 'ElektRe', 32233, 'AS123', 12),
(9, 'Tychy', 'Giżycko', 'Telefony', 'TelSped', 120200, 'EE11', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flota`
--
ALTER TABLE `flota`
  ADD PRIMARY KEY (`id_pojazdu`);

--
-- Indexes for table `kierowcy`
--
ALTER TABLE `kierowcy`
  ADD PRIMARY KEY (`id_kierowcy`);

--
-- Indexes for table `zlecenia`
--
ALTER TABLE `zlecenia`
  ADD PRIMARY KEY (`id_zlecenia`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flota`
--
ALTER TABLE `flota`
  MODIFY `id_pojazdu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `kierowcy`
--
ALTER TABLE `kierowcy`
  MODIFY `id_kierowcy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `zlecenia`
--
ALTER TABLE `zlecenia`
  MODIFY `id_zlecenia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
