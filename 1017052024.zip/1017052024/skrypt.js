function LICZ() {
    const km = document.getElementById('.km').value;
    const w = document.getElementById('.w').value;
    const transport = document.getElementById('input[name="transport"]:checked').value;

    let cena = 0;

    if (transport === 'lodowa') {
        cena = 3 * km + 0.5 * w;
    } else if (transport === 'express') {
        cena = 5 * km + 1.5 * w;
    } else if (transport === 'big') {
        cena = 3.5 * km + 1 * w;
    }

    document.getElementById('.wynik').innerHTML = "Cena zlecenia:" +cena+ "zł";
}
