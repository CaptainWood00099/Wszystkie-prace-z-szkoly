var obrazek1=new Image();
obrazek1.src='obrazek1.jpg';
var obrazek2=new Image();
obrazek2.src='obrazek2.jpg';		
var licznik=1;
function zmienObrazek()
{
    var obraz=document.getElementById('obrazek');
    if (licznik%3==1) 
    {
        obraz.src=obrazek2.src;
        licznik++;
    }
    else if(licznik%3==2)
    {
        obraz.src=obrazek3.src;
        licznik++;
    }
    else{
        obraz.src=obrazek4.src;
        licznik++;  
    }
}
