var pies1=new Image()
pies1.src='pies1.jpg'
var pies2=new Image()
pies2.src='pies2.jpg'
var pies3=new Image()
pies3.src='pies3.jpg'
var kot1=new Image()
kot1.src='kot1.jpg'
var kot2=new Image()
kot2.src='kot2.jpg'
var kot3=new Image()
kot3.src='kot3.jpg'
var pies1k=new Image()
pies1k.src='pies1szary.jpg'
var pies2k=new Image()
pies2k.src='pies2szary.jpg'
var pies3k=new Image()
pies3k.src='pies3szary.jpg'
var kot1k=new Image()
kot1k.src='kot1szary.jpg'
var kot2k=new Image()
kot2k.src='kot2szary.jpg'
var kot3k=new Image()
kot3k.src='kot3szary.jpg'
var obraz=document.getElementById('obrazek')
function dog12(){
    obraz.src=pies1k.src;
    }
function dog22(){
    obraz.src=pies2k.src;
        }
function dog32(){
    obraz.src=pies3k.src;
     }
     function cat11(){
        obraz.src=kot1k.src;
        }
    function cat21(){
        obraz.src=kot2k.src;
            }
    function cat31(){
        obraz.src=kot3k.src;
         }