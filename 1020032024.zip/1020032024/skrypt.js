function licz(){
    var quant=document.getElementById("ilosc").value;
    var upust=document.getElementById("new").checked;
    let cena=0;
    if(quant>0 && quant<=50){
        if(upust==true){
            cena=quant*1.8;
            document.getElementById("wynik").innerHTML="Koszt ogłoszeń: " +cena+ " PLN";
        }else{
            cena=quant*2;
            document.getElementById("wynik").innerHTML="Koszt ogłoszeń: " +cena+ " PLN";
        }
    }else if(quant>50){
        if(upust==true){
            cena=quant*0.8;
            document.getElementById("wynik").innerHTML="Koszt ogłoszeń: " +cena+ " PLN";
        }else{
            cena=quant;
            document.getElementById("wynik").innerHTML="Koszt ogłoszeń: " +cena+ " PLN";
        }
    }
}