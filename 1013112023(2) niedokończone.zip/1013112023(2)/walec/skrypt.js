function Objetosc(){
    let r = parseFloat(document.getElementById("promien").value);
    let h = parseFloat(document.getElementById("wysokosc").value);
    if (!isNaN(r) && !isNaN(h)) {
    V=Math.PI*(r*r)*h;
    document.getElementById("wynik").innerHTML="Objętość wynosi "+V.toFixed(2);
    }else{
        alert("Podaj promień koła!");
    //document.getElementById("wynik").innerHTML="Podaj promień kuli!";    
    }
}
function Pole(){
    let r = parseFloat(document.getElementById("promien").value);
    let h = parseFloat(document.getElementById("wysokosc").value);
    if (!isNaN(r) && !isNaN(h)) {
    P=2*Math.PI*r*(r+h);
    document.getElementById("wynik").innerHTML="Pole powierzchni wynosi "+P.toFixed(2);
    }else{
    //alert("Podaj promień kuli!");
    document.getElementById("wynik").innerHTML="Podaj promień koła!";
    }
}