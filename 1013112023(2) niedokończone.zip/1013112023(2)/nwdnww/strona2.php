<!DOCTYPE html>
<html>
<head>
  <title>Strona główna</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
<a href="index.html"><img src="baner.jpg" alt="baner" id="dzial"></a>
</header>
<div id="srodek">
<a href="strona1.html"><img src="js.png" alt="JavaScript" id="js"></a>
<a href="strona2.php"><img src="php.png" alt="PHP" id="php"></a>
<h2>Znajdujesz się na stronie o tematyce matematycznej.</h2>
<p>Zadanie wykonane w języku PHP. </p>
<form action="" method="GET">
Podaj promień walca <input type="number" name="r"> <br>
Podaj wysokość walca <input type="number" name="h"> <br> <br>
    <input type="submit" value="Licz objętość oraz Pole powierzchni walca">
    <br> <br>
<?php
    if (isset($_GET["r"])){
      $r=$_GET['r'];
      $h=$_GET['h'];
    $obj=pi()*($r*$r)*$h;
    echo "Objetosc walca wynosi: ".round($obj,2);
      $Pp=pi()*($r*$r)
      $Pb=(2*)pi()*($h)
    $pole=(2*$Pp)+$Pb
    echo ", a pole powierzchni całkowitej: ".round($pole,2);
    }else{
      echo "Podaj promień okręgu!";
      }
  ?>
</div>

<footer>Autor szablonu: Wieczorek Wojciech</footer>>
</body>
</html>