function NWD(){
    let a = parseFloat(document.getElementById("x").value);
    let b = parseFloat(document.getElementById("y").value);
    if (!isNaN(a) && !isNaN(b)) {
        while (a != b) {
            if (a < b) {
              pom = a; a = b; b = pom;
            }
            a = a - b;
          }
          document.write("najwiekszywspolnydzielnik: "+a);
    }else{
        alert("Podaj wartosci!");
    //document.getElementById("wynik").innerHTML="Podaj promień kuli!";    
    }
}
function NWW(){
    let a = parseFloat(document.getElementById("x").value);
    let b = parseFloat(document.getElementById("y").value);
    if (!isNaN(a) && !isNaN(b)) {
    P=2*Math.PI*r*(r+h);
    document.getElementById("wynik").innerHTML="Pole powierzchni wynosi "+P.toFixed(2);
    }else{
    //alert("Podaj promień kuli!");
    document.getElementById("wynik").innerHTML="Podaj wartości!";
    }
}
