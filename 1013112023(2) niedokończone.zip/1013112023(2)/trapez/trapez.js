function trapez() {
    let a = parseFloat(document.getElementById("bok1").value);
    let b = parseFloat(document.getElementById("bok2").value);
    let h = parseFloat(document.getElementById("wysokosc").value);
    if (!isNaN(a) && !isNaN(b) && !isNaN(h)) {
        let POLE = ((a + b) / 2) * h;
        document.getElementById("wynik").innerHTML = "Pole wynosi: " + POLE;
    } else {
        document.getElementById("wynik").innerHTML = "Podaj wymiary!";
    }
}