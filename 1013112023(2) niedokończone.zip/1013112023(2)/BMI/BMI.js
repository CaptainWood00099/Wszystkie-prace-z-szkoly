function BMI() {
    let h = parseFloat(document.getElementById("h").value);
    let w = parseFloat(document.getElementById("w").value);
    if (!isNaN(h) && !isNaN(w) && h > 0 && w > 0) {
        let BMI = w / (h * h);

        if (BMI < 18.5) {
            document.getElementById("wynik").innerHTML = "Twoje BMI wynosi " + BMI.toFixed(2) + " jest to niedowaga";
        } else if (BMI >= 18.5 && BMI < 24.9) {
            document.getElementById("wynik").innerHTML = "Twoje BMI wynosi " + BMI.toFixed(2) + " jest to prawidłowa waga";
        } else if (BMI >= 25 && BMI < 29.9) {
            document.getElementById("wynik").innerHTML = "Twoje BMI wynosi " + BMI.toFixed(2) + " jest to nadwaga";
        } else {
            document.getElementById("wynik").innerHTML = "Twoje BMI wynosi " + BMI.toFixed(2) + " jest to otyłość";
        }
    } else {
        alert("Podaj poprawne wartości!");
    }
}