<!DOCTYPE html>
<html>
<head>
  <title>Strona główna</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
<a href="index.html"><img src="baner.jpg" alt="baner" id="dzial"></a>
</header>
<div id="srodek">
<a href="strona1.html"><img src="js.png" alt="JavaScript" id="js"></a>
<a href="strona2.php"><img src="php.png" alt="PHP" id="php"></a>
<h2>Znajdujesz się na stronie o tematyce matematycznej.</h2>
<p>Zadanie wykonane w języku PHP. </p>
<form action="" method="GET">
Podaj wage w kg <input type="number" name="w"> <br>
Podaj wysokość <input type="number" name="h"> <br> <br>
    <input type="submit" value="Licz BMI">
    <br> <br>
    <?php
      if (isset($_GET["w"]) && isset($_GET["h"])) {
        $w = $_GET["w"];
        $h = $_GET["h"];
        $BMI = $w / ($h * $h);
        echo "Twoje BMI wynosi: " . $BMI;

        if ($BMI < 18.5) {
          echo " Niedowaga";
        } else if ($BMI >= 18.5 && $BMI < 24.9) {
          echo " Prawidłowa waga";
        } else if ($BMI >= 25 && $BMI < 29.9) {
          echo " Nadwaga";
        } else {
          echo " Otyłość";
        }
      } else {
        echo "Podaj wagę i wysokość!";
      }
      ?>
</div>

<footer>Autor szablonu: Wieczorek Wojciech</footer>>
</body>
</html>