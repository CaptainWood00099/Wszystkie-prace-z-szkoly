function zapisz2(){
    let a=document.getElementById("t3").value;
    let b=document.getElementById("t4").value;
    document.getElementById("wynik6").innerHTML="substr " +a.substring(a,6);
    document.getElementById("wynik7").innerHTML="replace " +b.replace("test", "poprawnie");
    document.getElementById("wynik8").innerHTML="search " +b.search("fakt");
    document.getElementById("wynik9").innerHTML="endsWith "+b.endsWith("a");
}