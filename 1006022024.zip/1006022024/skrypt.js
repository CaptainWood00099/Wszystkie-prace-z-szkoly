function zapisz(){
    let x=document.getElementById("t1").value;
    let y=document.getElementById("t2").value;
    let dlugosc=x+y;
    document.getElementById("wynik1").innerHTML="Mój tekst_1 " +x;
    document.getElementById("wynik2").innerHTML="Mój tekst_2 wielkimi literami " +y.toUpperCase();
    document.getElementById("wynik3").innerHTML="Mój tekst_1 ma " +x.length+ " znaków";
    document.getElementById("wynik4").innerHTML="Oba teksty sklejone " .concat(x,y);
    document.getElementById("wynik5").innerHTML="Moje złączone teksty mają " +dlugosc.length;
};
function zapisz2(){
    let a=document.getElementById("t3").value;
    let b=document.getElementById("t4").value;
    document.getElementById("wynik6").innerHTML="substr " +a.substring(a,6);
    document.getElementById("wynik7").innerHTML="replace "b.replace("test", "poprawnie");
    document.getElementById("wynik8").innerHTML="search " b.search("fakt");
    document.getElementById("wynik9").innerHTML="endsWith "b.endsWith("a");
}