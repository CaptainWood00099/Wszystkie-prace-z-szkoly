function fibon()
{
    let a1 = parseInt(document.getElementById("A1").value)
    let r = parseInt(document.getElementById("R").value)
    let n = parseInt(document.getElementById("N").value)
    let wyn = a1
    let arr = []

    for(i = 0; i < n; i++){
        arr[i] = a1
        a1 += r;
    }

    document.getElementById("output").innerHTML = `Ciąg arytmetyczny zawiera: ${arr}`
}