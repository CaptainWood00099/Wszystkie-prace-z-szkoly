<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="hobby.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasze hobby</title>
</head>
<body>
    <section class="banner">
<h1>FORUM HOBBYSTYCZNE</h1>
    </section>
<section class="RIGTH">
<h3>TEMATY FORUM</h3>
<ul>
    <li>Hodowlna zwierząt</li>
    <ul>
        <li>psy</li>
        <li>koty</li>
    </ul>
    <li>Muzyka</li>
    <li>Gry komputerowe</li>
</ul>
<ol>
    <li>Insturmenty muzyczne</li>
    <li>Sprzęt audio</li>
    <li>Płyty CD</li>
</ol>
</section>
<section class="LEFTPHP">
<?php

$conn=mysqli_connect("localhost", "root", "", "Forum");
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $nick=$_POST["nick"];
$hobby=$_POST['hobby'];
$job=$_POST['job'];
$woman=$_POST['woman'];
$man=$_POST['man'];
$login=$_POST['login'];
$pass=$_POST['pass'];
echo "Konto " .$nick. " <nazwisko> zostało zarejestrowane na forum hobbystycznym"; 
$uzytk="INSERT INTO uzytkownicy(nick, zainteresowania, zawod, plec) VALUES($nick, $hobby, $job, $man)";
$Konta="INSERT INTO konta(login, haslo) VALUES ($login, $pass)"; 
}
mysqli_close($conn);

?>
</section>
</body>
</html>