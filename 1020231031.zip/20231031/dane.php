<?php
echo "Witam ".$_POST['imie']." " .$_POST['nazwisko']."<br>";
echo "Jesteś " .(($_POST['plec']=="m")?"mężczyzną":"kobietą")."<br>";
?>