<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl1.css">
    <title>Hurtownia</title>
</head>
<body>
    
<div class="logo">
    <img src="komputer.png" alt="hurtownia komputerowa">
</div>

<div class="lista">
<ul>
<li>Sprzęt</li>
<li>Procesory</li>
<li>Pamięci RAM</li>
<li>Monitory</li>
<li>Karty graficzne</li>
<li>Dyski twarde</li>
</ul>
</div>

<div class="formularz">
<h2>Hurtownia komputerowa</h2>
<form action="" method="POST">
    Wybierz kategorie sprzętu
    <input type="number" name="hardware" id="">
    <input type="submit" value="SPRAWDŹ">
</form>
</div>

<div class="main">
<h1>Podzesppoły we wskazanej kategorii</h1>
<?php
      if(isset($_POST["hardware"])){
        $conn = mysqli_connect("localhost", "root", "", "sklep");
        $input = $_POST["category"];
        $query = "SELECT nazwa, opis, cena FROM podzespoly WHERE typy_id = $input";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_assoc($result)){
          echo $row["nazwa"] . " " . $row["opis"] . " " . $row["cena"] . "<br>";
        }
        mysqli_close($conn);
      }
    ?>
</div>

<footer>
    <h3>Hurtownia działa od poniedziałku do soboty w godzinach 7<sup>00</sup>-16<sup>00</sup></h3>
    <a href="bok@hurtownia.pl">Napisz do nas</a>
    Partnerzy
    <a href="http://intel.pl/" target="_blank">Intel</a>
    <a href="http://amd.pl/" target="_blank">AND</a>
    <p>Stronę wykonał 1008012024</p>
</footer>
</body>
</html>