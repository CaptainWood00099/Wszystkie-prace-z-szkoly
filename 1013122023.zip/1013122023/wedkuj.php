<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styl_1.css">
    <title>Wędkujemy</title>
</head>
<body>
    <div class="banner">
    <h2>Portal dla wędkarzy</h2>
    </div>

    <div class="left">
<h2>Ryby drapieżne naszych wód</h2>
<?php
$conn=mysqli_connect("localhost", "root", "", "wędkowanie");
$res=mysqli_query($conn, "SELECT * FROM ryby");
while($row= mysqli_fetch_array($res)){
    echo" <ul> 
    <li>$row[0] $row[1] występowanie $row[2]</li>
    </ul>";
}mysqli_close($con);
?>
    </div>

    <div class="right">
<img src="ryba1.jpg" alt="Sum">
<a href="kwerendy.txt">Pobierz kwerendy</a>
    </div>

    <footer>
Stronę wykonał: 1113122023
    </footer>

</body>
</html>