
function BEES() {
    const obraz1 = document.getElementById("BEES");
    const opcja = document.querySelector('input[name="bee"]:checked').value;

    switch (opcja) {
        case "Blur":
            obraz1.style.filter = "blur(5px)";
            break;
        case "Sepia":
            obraz1.style.filter = "sepia(100%)";
            break;
        case "Negatyw":
            obraz1.style.filter = "invert(100%)";
            break;
    }
}
function treeC() {
    const obraz2 = document.getElementById("tree");
    obraz2.style.filter = "none";
}
function treeB() {
    const obraz2 = document.getElementById("tree");
    obraz2.style.filter = "grayscale(100%)";
}
function grapes() {
    const obraz3 = document.getElementById("wino");
    const widocznosc = document.getElementById("grape").value;
    obraz3.style.filter = "opacity("+widocznosc+"%)";
}
//obraz4
function turtle() {
    const obraz4 = document.getElementById("turtles");
    const nasycenie = document.getElementById("turtle").value;
    obraz4.style.filter = "brightness("+nasycenie+"%)";
}
